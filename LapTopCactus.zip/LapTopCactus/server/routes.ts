import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import z from "zod";

// Contact message schema
const contactSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  subject: z.string().optional(),
  message: z.string().min(10, { message: "Message must be at least 10 characters" })
});

type ContactMessage = z.infer<typeof contactSchema>;

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for contact form submissions
  app.post('/api/contact', async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const result = contactSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Validation failed", 
          errors: result.error.errors 
        });
      }
      
      const contactData = result.data;
      
      // Here you would typically save this to a database
      // or send an email notification
      console.log('Contact form submission:', contactData);

      // Return success response
      return res.status(200).json({ 
        message: "Message received! We'll get back to you soon.",
        success: true
      });
    } catch (error) {
      console.error('Error processing contact form:', error);
      return res.status(500).json({ 
        message: "An error occurred while processing your request",
        success: false
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
