import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Preload fonts
const fontLinks = [
  "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap"
];

fontLinks.forEach(href => {
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = href;
  document.head.appendChild(link);
});

// Set title
document.title = "The British Finish";

createRoot(document.getElementById("root")!).render(<App />);
