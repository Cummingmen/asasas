import { useEffect, useRef } from 'react';

interface ParallaxOptions {
  speed?: number;
}

export const useParallax = (options: ParallaxOptions = {}) => {
  const { speed = 0.05 } = options;
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const handleMouseMove = (e: MouseEvent) => {
      const x = e.clientX;
      const y = e.clientY;
      
      const xPos = (window.innerWidth / 2 - x) * speed;
      const yPos = (window.innerHeight / 2 - y) * speed;
      
      element.style.transform = `translate(${xPos}px, ${yPos}px)`;
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [speed]);

  return ref;
};
