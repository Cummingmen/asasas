import React from 'react';
import { motion } from 'framer-motion';
import WaveEffect from './WaveEffect';
import { ChevronDown } from 'lucide-react';

const HeroSection: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <section id="hero" className="relative h-screen flex items-center overflow-hidden">
      <div className="wave-container absolute top-0 left-0 w-full h-full">
        <WaveEffect opacity={0.2} />
        <WaveEffect opacity={0.3} delay={-5} top="10%" />
        <WaveEffect opacity={0.1} delay={-10} top="20%" />
      </div>
      
      <div className="container mx-auto px-8 md:px-12 relative z-10">
        <motion.div 
          className="max-w-4xl"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.h1 
            className="heading-xl"
            variants={itemVariants}
          >
            Crafting <span className="text-[#B80C09]">British</span> Excellence in Digital Experience
          </motion.h1>
          <motion.p 
            className="paragraph"
            variants={itemVariants}
          >
            Elevating digital presence with sophisticated design solutions - where tradition meets innovation.
          </motion.p>
          <motion.div 
            className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
            variants={itemVariants}
          >
            <a 
              href="#work" 
              className="inline-block bg-[#0A2463] text-white px-8 py-4 rounded hover:bg-opacity-90 transition-all duration-300 text-center"
            >
              Explore Our Work
            </a>
            <a 
              href="#contact" 
              className="inline-block border-2 border-[#0A2463] text-[#0A2463] px-8 py-4 rounded hover:bg-[#0A2463] hover:text-white transition-all duration-300 text-center"
            >
              Get in Touch
            </a>
          </motion.div>
        </motion.div>
      </div>
      
      <motion.div 
        className="absolute bottom-12 left-1/2 transform -translate-x-1/2 cursor-pointer"
        initial={{ y: -10, opacity: 0.8 }}
        animate={{ y: 10, opacity: 1 }}
        transition={{ repeat: Infinity, repeatType: "reverse", duration: 1.5 }}
      >
        <a href="#about">
          <ChevronDown className="h-8 w-8 text-[#0A2463]" />
        </a>
      </motion.div>
    </section>
  );
};

export default HeroSection;
