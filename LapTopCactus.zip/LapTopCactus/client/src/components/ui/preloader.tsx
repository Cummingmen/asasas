import React from 'react';

export function Preloader() {
  return (
    <div className="fixed top-0 left-0 w-full h-full bg-[#0A2463] flex justify-center items-center z-[9999] transition-all duration-1000">
      <div className="relative overflow-hidden">
        <h1 className="text-white font-playfair text-4xl md:text-5xl">
          The British Finish
        </h1>
        <div className="absolute top-0 right-0 w-full h-full bg-[#0A2463] animate-reveal"></div>
      </div>
      <style jsx>{`
        @keyframes reveal {
          0% { width: 100%; }
          100% { width: 0; }
        }
        .animate-reveal {
          animation: reveal 2s cubic-bezier(.77,0,.18,1);
        }
      `}</style>
    </div>
  );
}
