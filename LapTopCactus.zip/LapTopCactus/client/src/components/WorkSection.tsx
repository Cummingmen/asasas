import React from 'react';
import { motion } from 'framer-motion';
import { useScrollReveal } from '@/lib/useScrollReveal';
import { ExternalLink } from 'lucide-react';

const WorkSection: React.FC = () => {
  const { ref: titleRef, isVisible: titleVisible } = useScrollReveal();
  const { ref: featuredRef, isVisible: featuredVisible } = useScrollReveal();
  const { ref: project1Ref, isVisible: project1Visible } = useScrollReveal();
  const { ref: project2Ref, isVisible: project2Visible } = useScrollReveal();

  return (
    <section id="work" className="py-20 md:py-32 relative">
      <div className="container mx-auto px-8 md:px-12">
        <motion.div 
          ref={titleRef as React.RefObject<HTMLDivElement>}
          className="max-w-4xl mx-auto text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={titleVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="font-playfair text-3xl md:text-5xl font-bold mb-6 text-[#0A2463]">Our Work</h2>
          <p className="text-lg text-[#1A1A1A]/80">A showcase of our finest projects, each delivered with the utmost attention to detail.</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Featured Project */}
          <motion.div 
            ref={featuredRef as React.RefObject<HTMLDivElement>}
            className="col-span-1 md:col-span-2 bg-white rounded-lg overflow-hidden shadow-xl"
            initial={{ opacity: 0, y: 50 }}
            animate={featuredVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="image-hover h-80 lg:h-auto">
                <img 
                  src="https://images.unsplash.com/photo-1483726234545-481d6e880fc6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="English countryside with stone cottage" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-8 lg:p-12 flex flex-col justify-center">
                <div className="text-[#B80C09] font-medium mb-3">Featured Project</div>
                <h3 className="text-2xl font-bold mb-4 font-playfair">Cotswold Luxury Retreats</h3>
                <p className="mb-6 text-[#1A1A1A]/80">
                  A bespoke digital platform showcasing exclusive countryside retreats across the Cotswolds, featuring immersive visuals and seamless booking experiences.
                </p>
                <div className="flex flex-wrap gap-2 mb-8">
                  <span className="px-3 py-1 bg-[#0A2463]/10 rounded-full text-sm">Web Design</span>
                  <span className="px-3 py-1 bg-[#0A2463]/10 rounded-full text-sm">UX/UI</span>
                  <span className="px-3 py-1 bg-[#0A2463]/10 rounded-full text-sm">Development</span>
                </div>
                <a href="#" className="text-[#0A2463] font-medium hover:text-[#B80C09] transition-colors duration-300 inline-flex items-center">
                  View Case Study
                  <ExternalLink className="h-4 w-4 ml-2" />
                </a>
              </div>
            </div>
          </motion.div>
          
          {/* Project 1 */}
          <motion.div 
            ref={project1Ref as React.RefObject<HTMLDivElement>}
            className="bg-white rounded-lg overflow-hidden shadow-xl h-80 relative group"
            initial={{ opacity: 0, y: 50 }}
            animate={project1Visible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <div className="image-hover absolute inset-0">
              <img 
                src="https://images.unsplash.com/photo-1543832923-44667a44c804?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" 
                alt="London Eye" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A2463]/80 to-transparent p-8 flex flex-col justify-end transform translate-y-8 group-hover:translate-y-0 opacity-90 group-hover:opacity-100 transition-all duration-300">
              <h3 className="text-xl font-bold mb-2 text-white font-playfair">London Tourism App</h3>
              <p className="text-white/90 mb-4 hidden group-hover:block transition-all duration-300">
                Interactive mobile app guiding tourists through London's iconic landmarks.
              </p>
              <a href="#" className="text-[#FFD700] hover:underline inline-flex items-center">
                View project
                <ExternalLink className="h-4 w-4 ml-2" />
              </a>
            </div>
          </motion.div>
          
          {/* Project 2 */}
          <motion.div 
            ref={project2Ref as React.RefObject<HTMLDivElement>}
            className="bg-white rounded-lg overflow-hidden shadow-xl h-80 relative group"
            initial={{ opacity: 0, y: 50 }}
            animate={project2Visible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
          >
            <div className="image-hover absolute inset-0">
              <img 
                src="https://images.unsplash.com/photo-1493707553966-283afac8c358?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80" 
                alt="British countryside" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A2463]/80 to-transparent p-8 flex flex-col justify-end transform translate-y-8 group-hover:translate-y-0 opacity-90 group-hover:opacity-100 transition-all duration-300">
              <h3 className="text-xl font-bold mb-2 text-white font-playfair">Heritage Trust Rebrand</h3>
              <p className="text-white/90 mb-4 hidden group-hover:block transition-all duration-300">
                Complete identity redesign for a prestigious British heritage conservation organization.
              </p>
              <a href="#" className="text-[#FFD700] hover:underline inline-flex items-center">
                View project
                <ExternalLink className="h-4 w-4 ml-2" />
              </a>
            </div>
          </motion.div>
        </div>
        
        <div className="text-center">
          <a href="#" className="inline-block border-2 border-[#0A2463] text-[#0A2463] px-8 py-4 rounded hover:bg-[#0A2463] hover:text-white transition-all duration-300">
            View All Projects
          </a>
        </div>
      </div>
    </section>
  );
};

export default WorkSection;
