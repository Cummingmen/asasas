import React from 'react';
import { motion } from 'framer-motion';
import { useScrollReveal } from '@/lib/useScrollReveal';
import { useParallax } from '@/lib/useParallax';

const AboutSection: React.FC = () => {
  const { ref: textRef, isVisible: textVisible } = useScrollReveal();
  const { ref: imageRef, isVisible: imageVisible } = useScrollReveal();
  
  const mainParallaxRef = useParallax({ speed: 0.05 });
  const smallParallaxRef = useParallax({ speed: 0.09 });

  return (
    <section id="about" className="py-20 md:py-32 relative overflow-hidden">
      <div className="container mx-auto px-8 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div 
            ref={textRef as React.RefObject<HTMLDivElement>}
            initial={{ opacity: 0, y: 100 }}
            animate={textVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h2 className="font-playfair text-3xl md:text-4xl font-bold mb-6 text-gradient">Our British Heritage</h2>
            <p className="text-lg mb-6">
              With deep roots in British design traditions, we blend timeless elegance with cutting-edge digital innovation.
            </p>
            <p className="text-lg mb-8">
              Our approach combines meticulous attention to detail, bold creative thinking, and technical excellence—values that have defined British craftsmanship for generations.
            </p>
            <div className="flex space-x-4 items-center">
              <div className="w-12 h-1 bg-[#B80C09]"></div>
              <p className="text-[#0A2463] font-medium">Established 2023</p>
            </div>
          </motion.div>
          
          <motion.div 
            ref={imageRef as React.RefObject<HTMLDivElement>}
            className="relative parallax h-[500px]"
            initial={{ opacity: 0, y: 100 }}
            animate={imageVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
          >
            <div 
              ref={mainParallaxRef}
              className="parallax-layer image-hover rounded-lg shadow-xl overflow-hidden h-full" 
            >
              <img 
                src="https://images.unsplash.com/photo-1486299267070-83823f5448dd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                alt="London Bridge" 
                className="w-full h-full object-cover"
              />
            </div>
            <div 
              ref={smallParallaxRef}
              className="absolute -bottom-6 -right-6 w-48 h-48 rounded-lg shadow-xl overflow-hidden parallax-layer image-hover"
            >
              <img 
                src="https://images.unsplash.com/photo-1488747279002-c8523379faaa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80" 
                alt="British telephone booth" 
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
