import React from 'react';
import { motion } from 'framer-motion';
import { useScrollReveal } from '@/lib/useScrollReveal';
import { Monitor, Smartphone, Paintbrush } from 'lucide-react';
import { WhiteWaveEffect } from './WaveEffect';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  delay?: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ title, description, icon, delay = 0 }) => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <motion.div
      ref={ref as React.RefObject<HTMLDivElement>}
      className="bg-white/5 backdrop-blur-sm rounded-lg p-8 transition-all duration-300 hover:scale-105 hover:bg-white/10"
      initial={{ opacity: 0, y: 50 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay }}
    >
      <div className="w-16 h-16 rounded-full bg-[#FFD700] flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-4">{title}</h3>
      <p className="opacity-80 mb-6">{description}</p>
      <a href="#" className="text-[#FFD700] hover:underline inline-flex items-center">
        Learn more
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
        </svg>
      </a>
    </motion.div>
  );
};

const ServicesSection: React.FC = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section id="services" className="py-20 md:py-32 bg-[#0A2463] text-white relative overflow-hidden">
      <div className="wave-container absolute top-0 left-0 w-full h-full">
        <WhiteWaveEffect opacity={0.1} />
      </div>
      
      <div className="container mx-auto px-8 md:px-12 relative z-10">
        <motion.div 
          ref={ref as React.RefObject<HTMLDivElement>}
          className="max-w-4xl mx-auto text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg">Our Services</h2>
          <p className="text-lg opacity-90">Delivering premium digital solutions with British precision and elegance.</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ServiceCard 
            title="Web Design" 
            description="Crafting visually stunning and intuitive websites that embody the sophistication of British design."
            icon={<Monitor className="h-8 w-8 text-[#0A2463]" />}
          />
          
          <ServiceCard 
            title="Mobile Development" 
            description="Creating seamless mobile experiences with the precision and reliability that British engineering is known for."
            icon={<Smartphone className="h-8 w-8 text-[#0A2463]" />}
            delay={0.1}
          />
          
          <ServiceCard 
            title="Branding" 
            description="Developing distinctive brand identities that capture the essence of British heritage with a contemporary twist."
            icon={<Paintbrush className="h-8 w-8 text-[#0A2463]" />}
            delay={0.2}
          />
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
