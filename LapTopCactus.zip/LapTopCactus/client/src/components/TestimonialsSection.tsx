import React from 'react';
import { motion } from 'framer-motion';
import { useScrollReveal } from '@/lib/useScrollReveal';
import { Star } from 'lucide-react';
import WaveEffect from './WaveEffect';

interface TestimonialProps {
  quote: string;
  author: string;
  position: string;
  initials: string;
  delay?: number;
}

const Testimonial: React.FC<TestimonialProps> = ({ quote, author, position, initials, delay = 0 }) => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <motion.div
      ref={ref as React.RefObject<HTMLDivElement>}
      className="bg-white/5 backdrop-blur-sm p-8 rounded-lg"
      initial={{ opacity: 0, y: 50 }}
      animate={isVisible ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay }}
    >
      <div className="flex items-center mb-6">
        <div className="text-[#FFD700]">
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-current" />
            ))}
          </div>
        </div>
      </div>
      <blockquote className="mb-6 italic opacity-90">
        "{quote}"
      </blockquote>
      <div className="flex items-center">
        <div className="mr-4">
          <div className="w-12 h-12 bg-[#FFD700]/20 rounded-full flex items-center justify-center text-[#FFD700]">
            {initials}
          </div>
        </div>
        <div>
          <div className="font-bold">{author}</div>
          <div className="text-sm opacity-80">{position}</div>
        </div>
      </div>
    </motion.div>
  );
};

const TestimonialsSection: React.FC = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="py-20 md:py-32 bg-gradient-to-r from-[#0A2463] to-[#0A2463]/90 text-white relative overflow-hidden">
      <div className="wave-container absolute top-0 left-0 w-full h-full">
        <WaveEffect color="#FFFFFF" opacity={0.1} />
      </div>
      
      <div className="container mx-auto px-8 md:px-12 relative z-10">
        <motion.div 
          ref={ref as React.RefObject<HTMLDivElement>}
          className="max-w-4xl mx-auto text-center mb-16"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg">What Our Clients Say</h2>
          <p className="text-lg opacity-90">Trusted by leading British and international organizations.</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Testimonial 
            quote="The British Finish transformed our digital presence with a website that perfectly balances traditional British elegance with modern functionality. Their attention to detail is impeccable."
            author="James Smith"
            position="CEO, Heritage Textiles"
            initials="JS"
          />
          
          <Testimonial 
            quote="Working with The British Finish was an absolute pleasure. They delivered our mobile app with remarkable attention to detail and an intuitive user experience that has delighted our customers."
            author="Emma Clarke"
            position="Marketing Director, Royal Tours"
            initials="EC"
            delay={0.1}
          />
          
          <Testimonial 
            quote="The brand identity The British Finish created for us perfectly captures our heritage while positioning us for the future. Their work has resulted in a 40% increase in customer engagement."
            author="Richard Bennett"
            position="Founder, Classic British Footwear"
            initials="RB"
            delay={0.2}
          />
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
