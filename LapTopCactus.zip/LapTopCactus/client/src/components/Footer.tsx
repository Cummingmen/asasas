import React from 'react';
import { Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0A2463] text-white py-12">
      <div className="container mx-auto px-8 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="font-playfair text-2xl font-bold mb-4">The British Finish</h3>
            <p className="mb-6 opacity-80 max-w-md">
              Blending traditional British design sensibilities with modern digital innovation to create distinctive online experiences.
            </p>
            <div className="flex space-x-4 mb-6">
              <a href="#" className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:bg-white hover:text-[#0A2463] transition-all duration-300">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:bg-white hover:text-[#0A2463] transition-all duration-300">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center hover:bg-white hover:text-[#0A2463] transition-all duration-300">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Sitemap</h4>
            <ul className="space-y-2">
              <li><a href="#" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Home</a></li>
              <li><a href="#about" className="opacity-80 hover:opacity-100 transition-opacity duration-300">About Us</a></li>
              <li><a href="#services" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Services</a></li>
              <li><a href="#work" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Our Work</a></li>
              <li><a href="#contact" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-4">Legal</h4>
            <ul className="space-y-2">
              <li><a href="#" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Privacy Policy</a></li>
              <li><a href="#" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Terms of Service</a></li>
              <li><a href="#" className="opacity-80 hover:opacity-100 transition-opacity duration-300">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="opacity-60 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} The British Finish. All rights reserved.
          </p>
          <p className="opacity-60 text-sm">
            Designed and developed with British precision.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
