import React from 'react';
import { motion } from 'framer-motion';

interface WaveEffectProps {
  className?: string;
  color?: string;
  opacity?: number;
  delay?: number;
  top?: string;
}

export const WaveEffect: React.FC<WaveEffectProps> = ({ 
  className = '',
  color = '#0A2463',
  opacity = 0.3,
  delay = 0,
  top = '0'
}) => {
  return (
    <motion.div 
      className={`absolute top-0 left-0 w-[200%] h-full ${className}`}
      style={{ 
        top, 
        opacity,
        background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='${encodeURIComponent(color)}' fill-opacity='${opacity}' d='M0,224L60,213.3C120,203,240,181,360,181.3C480,181,600,203,720,213.3C840,224,960,224,1080,213.3C1200,203,1320,181,1380,170.7L1440,160L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z'%3E%3C/path%3E%3C/svg%3E")`,
        backgroundRepeat: 'repeat-x',
      }}
      initial={{ x: 0 }}
      animate={{ x: '-50%' }}
      transition={{ 
        repeat: Infinity, 
        duration: 25, 
        ease: 'linear',
        delay
      }}
    />
  );
};

export const WhiteWaveEffect: React.FC<Omit<WaveEffectProps, 'color'>> = (props) => {
  return <WaveEffect {...props} color="#FFFFFF" />;
};

export default WaveEffect;
