import React, { useEffect, useState } from 'react';

const Cursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const updatePosition = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOut = () => {
      // Hide cursor when it leaves the window
      document.documentElement.style.setProperty('--cursor-visibility', 'hidden');
    };

    const handleMouseIn = () => {
      document.documentElement.style.setProperty('--cursor-visibility', 'visible');
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // Check if hovering over clickable elements
      if (target.tagName.toLowerCase() === 'a' || 
          target.tagName.toLowerCase() === 'button' ||
          target.closest('a') || 
          target.closest('button')) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', updatePosition);
    window.addEventListener('mouseout', handleMouseOut);
    window.addEventListener('mouseover', handleMouseIn);
    document.addEventListener('mouseover', handleMouseOver);

    // Clean up event listeners
    return () => {
      window.removeEventListener('mousemove', updatePosition);
      window.removeEventListener('mouseout', handleMouseOut);
      window.removeEventListener('mouseover', handleMouseIn);
      document.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <>
      <div 
        className="cursor cursor-dot pointer-events-none fixed z-[9999] mix-blend-difference"
        style={{
          width: isHovering ? '15px' : '8px',
          height: isHovering ? '15px' : '8px',
          backgroundColor: isHovering ? '#FFD700' : 'white',
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          left: `${position.x}px`,
          top: `${position.y}px`,
          transition: 'width 0.3s, height 0.3s, background-color 0.3s',
        }}
      />
      <div 
        className="cursor cursor-outline pointer-events-none fixed z-[9999]"
        style={{
          width: isHovering ? '60px' : '40px',
          height: isHovering ? '60px' : '40px',
          border: `1px solid ${isHovering ? 'rgba(255, 215, 0, 0.5)' : 'rgba(255, 255, 255, 0.5)'}`,
          borderRadius: '50%',
          transform: 'translate(-50%, -50%)',
          left: `${position.x}px`,
          top: `${position.y}px`,
          transition: 'all 0.1s ease-out',
        }}
      />
      <div 
        className="interactive-wave pointer-events-none fixed z-[9998]"
        style={{
          width: '200px',
          height: '200px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,215,0,0.2) 0%, rgba(255,215,0,0) 70%)',
          transform: 'translate(-50%, -50%)',
          left: `${position.x}px`,
          top: `${position.y}px`,
          opacity: 0.6,
          transition: 'opacity 0.3s ease-out',
        }}
      />
    </>
  );
};

export default Cursor;
