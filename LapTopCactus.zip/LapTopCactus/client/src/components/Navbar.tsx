import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
    // Toggle body scroll when menu is open
    if (!mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'visible';
    }
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
    document.body.style.overflow = 'visible';
  };

  return (
    <>
      <motion.nav 
        className={`fixed top-0 w-full z-50 py-6 px-8 md:px-12 flex justify-between items-center transition-all duration-500 ${
          isScrolled ? 'bg-white shadow-md' : ''
        }`}
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="logo">
          <a href="#" className="font-playfair text-2xl font-bold text-[#0A2463] hover:text-[#B80C09] transition-colors duration-300">
            The British Finish
          </a>
        </div>
        <div className="hidden md:flex space-x-8 items-center">
          <a href="#about" className="text-[#0A2463] hover:text-[#B80C09] transition-colors duration-300">About</a>
          <a href="#work" className="text-[#0A2463] hover:text-[#B80C09] transition-colors duration-300">Work</a>
          <a href="#services" className="text-[#0A2463] hover:text-[#B80C09] transition-colors duration-300">Services</a>
          <a href="#contact" className="text-[#0A2463] hover:text-[#B80C09] transition-colors duration-300">Contact</a>
        </div>
        <button 
          className="md:hidden text-[#0A2463] focus:outline-none" 
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
        </button>
      </motion.nav>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            className="fixed top-0 left-0 w-full h-full bg-[#0A2463] z-40 flex flex-col items-center justify-center"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "100%", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <button 
              className="absolute top-6 right-8 text-white"
              onClick={closeMobileMenu}
              aria-label="Close menu"
            >
              <X className="h-6 w-6" />
            </button>
            <div className="flex flex-col items-center justify-center h-full space-y-8 text-2xl">
              <a 
                href="#about" 
                className="text-white hover:text-[#FFD700] transition-colors duration-300"
                onClick={closeMobileMenu}
              >
                About
              </a>
              <a 
                href="#work" 
                className="text-white hover:text-[#FFD700] transition-colors duration-300"
                onClick={closeMobileMenu}
              >
                Work
              </a>
              <a 
                href="#services" 
                className="text-white hover:text-[#FFD700] transition-colors duration-300"
                onClick={closeMobileMenu}
              >
                Services
              </a>
              <a 
                href="#contact" 
                className="text-white hover:text-[#FFD700] transition-colors duration-300"
                onClick={closeMobileMenu}
              >
                Contact
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;
